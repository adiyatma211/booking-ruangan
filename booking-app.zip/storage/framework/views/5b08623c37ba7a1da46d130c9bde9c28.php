<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h3>Daftar Ruangan</h3>
        <p class="text-subtitle text-muted">Klik ruangan untuk melihat jadwal pemesanan</p>
    </div>

    <?php
        // Ambil opsi durasi unik dari DB
        $durasiOptions = collect($ruangans)
            ->pluck('max_jam')
            ->filter(fn($v) => is_numeric($v) && (int) $v > 0)
            ->map(fn($v) => (int) $v)
            ->unique()
            ->sort()
            ->values();
    ?>

    <!-- Filter Pencarian -->
    <div class="card mb-4 shadow-sm">
        <div class="card-body">
            <form id="filterForm" class="row g-3">
                <div class="col-md-6">
                    <label for="search" class="form-label">Cari Ruangan</label>
                    <input type="text" class="form-control" id="search" placeholder="Masukkan nama ruangan...">
                </div>
                <div class="col-md-3">
                    <label for="durasi" class="form-label">Durasi Maksimal</label>
                    <select id="durasi" class="form-select">
                        <option value="" selected>Semua</option>
                        <?php $__currentLoopData = $durasiOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($opt); ?>"><?php echo e($opt); ?> jam</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </form>
        </div>
    </div>

    <!-- Daftar Ruangan -->
    <div class="row">
        <?php $__currentLoopData = $ruangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $penuh = $ruangan->is_full ?? false;
                $gaps = $ruangan->available_gaps ?? [];
                $merged = $ruangan->merged_bookings ?? [];
                $route = route('kalender', $ruangan->id);

                $badgeClass = $penuh ? 'bg-danger' : 'bg-success';
                $badgeText = $penuh ? 'Penuh' : 'Tersedia';

                $bookLines = collect($merged)
                    ->map(fn($b) => ($b['from'] ?? '') . '–' . ($b['to'] ?? ''))
                    ->filter()
                    ->implode('|');
                $gapLines = collect($gaps)
                    ->map(fn($g) => ($g['from'] ?? '') . '–' . ($g['to'] ?? ''))
                    ->filter()
                    ->implode('|');
            ?>

            <div class="col-md-4 room-card" data-name="<?php echo e(strtolower($ruangan->nama)); ?>"
                data-maxjam="<?php echo e((int) $ruangan->max_jam); ?>">
                <div class="card shadow-sm mb-4 <?php echo e($penuh ? 'bg-light border-danger' : ''); ?>" style="cursor:pointer;"
                    onclick="window.location.href='<?php echo e($route); ?>'">
                    <div class="card-body">
                        <h5 class="card-title d-flex justify-content-between align-items-center">
                            <span><?php echo e($ruangan->nama); ?></span>
                            <span class="badge <?php echo e($badgeClass); ?>" data-has-tooltip="1" data-bookings="<?php echo e($bookLines); ?>"
                                data-gaps="<?php echo e($gapLines); ?>">
                                <?php echo e($badgeText); ?>

                            </span>
                        </h5>

                        <p class="card-text mb-2">Maksimal: <?php echo e($ruangan->max_jam); ?> jam</p>

                        <?php if(!$penuh && !empty($gaps)): ?>
                            <div class="small text-muted mb-1">Jam Tersedia Hari ini:</div>
                            <div class="d-flex flex-wrap gap-1">
                                <?php $__currentLoopData = $gaps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span
                                        class="badge bg-light text-dark border"><?php echo e($g['from']); ?>–<?php echo e($g['to']); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php elseif($penuh): ?>
                            <div class="small text-muted">Tidak ada kuota di jam operasional.</div>
                        <?php endif; ?>

                        <a href="<?php echo e($route); ?>" onclick="event.stopPropagation()" class="btn btn-primary mt-3">
                            Lihat Jadwal
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <style>
        .tooltip-wide .tooltip-inner {
            max-width: 300px;
            text-align: left;
            white-space: nowrap;
        }
    </style>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Tooltip
            document.querySelectorAll('[data-has-tooltip="1"]').forEach(function(el) {
                const books = (el.getAttribute('data-bookings') || '').split('|').filter(Boolean);
                const gaps = (el.getAttribute('data-gaps') || '').split('|').filter(Boolean);

                const bookHtml = books.length ? books.join('<br>') : '—';
                const gapHtml = gaps.length ? gaps.join('<br>') : '—';

                const html =
                    '<div class="text-start" style="min-width:220px">' +
                    '<div class="fw-semibold mb-1">Booking</div>' +
                    '<div class="small ' + (books.length ? '' : 'text-muted') + '">' + bookHtml + '</div>' +
                    '<hr class="my-2">' +
                    '<div class="fw-semibold mb-1">Slot tersedia</div>' +
                    '<div class="small ' + (gaps.length ? '' : 'text-muted') + '">' + gapHtml + '</div>' +
                    '</div>';

                new bootstrap.Tooltip(el, {
                    title: html,
                    html: true,
                    sanitize: false,
                    customClass: 'tooltip-wide',
                    placement: 'top',
                    trigger: 'hover focus'
                });
            });

            // Filter
            const form = document.getElementById('filterForm');
            const search = document.getElementById('search');
            const durasi = document.getElementById('durasi');
            const cards = Array.from(document.querySelectorAll('.room-card'));

            function normalize(str) {
                return (str || '').toString().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
            }

            function applyFilter() {
                const q = normalize(search.value);
                const minJam = durasi.value ? parseInt(durasi.value, 10) : null;

                cards.forEach(card => {
                    const name = normalize(card.dataset.name || '');
                    const maxJam = parseInt(card.dataset.maxjam || '0', 10);
                    const matchName = !q || name.includes(q);
                    const matchDur = (minJam === null) || (maxJam >= minJam);
                    card.classList.toggle('d-none', !(matchName && matchDur));
                });
            }

            const debounced = (fn, ms = 150) => {
                let t;
                return (...a) => {
                    clearTimeout(t);
                    t = setTimeout(() => fn(...a), ms);
                };
            };

            search.addEventListener('input', debounced(applyFilter, 150));
            durasi.addEventListener('change', applyFilter);
            form.addEventListener('submit', e => e.preventDefault());
            applyFilter();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\booking-app\resources\views/booking/v_book.blade.php ENDPATH**/ ?>